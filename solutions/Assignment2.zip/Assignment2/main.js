// Solution for assignment:

let background_1_location = "Assets/packing.jpeg";
let background_2_location = "Assets/juice-bar.jpeg";
let intro = document.getElementById("intro");

background = background_1_location;

function changeBackground(){
  intro.style.backgroundImage = "url('"+background+"')";
  if(background == "Assets/juice-bar.jpeg" ){
    background = background_1_location;
  }
  else{
    background = background_2_location;
  }
}



// DRY: Do not Repeat Yourself
setInterval(function() {
    changeBackground();
}, 1000)
